<?php

$conn = mysqli_connect('localhost:3307', 'root', '', 'hotel_booking_db');
if (!$conn) {
    echo "koneksi error";
}

?>